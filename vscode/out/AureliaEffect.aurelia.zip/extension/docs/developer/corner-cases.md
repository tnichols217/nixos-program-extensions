
# Template / View
- .html file with only this content does not gets parsed (issue with 3rd party html-parser?)
  ```html
  ${foo}
  ```
