
# Rename
- Why can't I rename the same variable again?
  --> You have to save the project for the extension to update the component list.