| Business Logic | Implementation |
| -------------- | -------------- |
| Files          | Documents      |
| Start up       | Initialization |
