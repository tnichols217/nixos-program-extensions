# Strategy
1. Focus on unit tests for Aurelia Server.
2. Minimal e2e setup
  Reason for "minimal": Mainly, ease of development, because for unit tesets, one can use Wallaby. An E2e test "cycle" (in development) takes too long.


# Missing

- [ ] detecting-on-init.feature
  Think of a way, to make this more accurate
  - [ ] the Perf todo