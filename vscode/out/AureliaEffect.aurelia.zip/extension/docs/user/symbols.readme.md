# Symbols

## General information
https://code.visualstudio.com/docs/editor/editingevolved#_go-to-symbol
https://code.visualstudio.com/docs/editor/editingevolved#_open-symbol-by-name

## How to trigger in VSCode
Shortcut:
  - Go to Symbol in Editor `Ctrl+Shift+o` or `Cmd+Shift+o`
  - Go to Symbol in Workspace `Ctrl+t` or `Cmd+t`

## Feature list
- Display *all* Aurelia related regions
  - in Editor
  - in Workspace

## Development

### Backlog
