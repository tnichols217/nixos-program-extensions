<table style="width:100%; border-collapse:collapse; font:16px Helvetica, Arial,sans-serif;">
  <tr>
    <td
      colspan="2"
      style="padding:5px 10px; background-color:#91AB6F"
    >
      <h1 style="font-size:30px; color:white;">Old School Table Layout</h1>
    </td>
  </tr>
  <tr style="height:210px;">
    <td style="width:25%; padding:20px; background-color:#B1D188; vertical-align: top;">
      <ul style="list-style:none; padding:0px; line-height:40px; font-size:19px;">
        <li><a
            href="#"
            style="color:#5B6B46;"
          >Home</a></li>
        <li><a
            href="#"
            style="color:#5B6B46;"
          >About</a></li>
        <li><a
            href="#"
            style="color:#5B6B46;"
          >Contact</a></li>
      </ul>
    </td>
    <td style="padding:20px; background-color:#C7EB98; vertical-align:top;">
      <h2>Welcome to our Old School site</h2>
      <p>Look at all these horrific table, tr tags and inline styles.</p>
      <p>This is very clean in terms of code too. Some table vased layouts had nested tables, within nested tables
        within nested tables!
    </td>
  </tr>
  <tr>
    <td
      colspan="2"
      style="padding:10px; background-color:#5B6B46; text-align:center;"
    >
      <p style="color:white">copyright &copy; OLDSCHOOL ltd</p>
    </td>
  </tr>
</table>