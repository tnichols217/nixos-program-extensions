### Preliminary high-level overview of the startup sequence from a lifecycle perspective:

![](https://www.lucidchart.com/publicSegments/view/54a2c1be-6e40-48a3-898c-a7ff815b4bdc/image.png)
