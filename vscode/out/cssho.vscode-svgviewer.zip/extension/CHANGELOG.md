# Changelog
## 2.0.0 (2019-02-28)
- [Upgrade to VS Code's webview API](https://github.com/cssho/vscode-svgviewer/issues/51)

## 1.4.7 (2018-10-10)
- [Buttons for zooming](https://github.com/cssho/vscode-svgviewer/issues/48)

## 1.4.6 (2018-09-10)
- [Support for external CSS missing](https://github.com/cssho/vscode-svgviewer/issues/41)

## 1.4.5 (2018-09-06)
- [Allow zooming of SVG with mouse wheel](https://github.com/cssho/vscode-svgviewer/issues/43)

## 1.4.4 (2018-05-08)
- [Bug: show Button when view extensions](https://github.com/cssho/vscode-svgviewer/issues/42)