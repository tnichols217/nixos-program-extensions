Copyright (c) 2021 Florian Klampfer <mail@qwtel.com> (https://qwtel.com/)

All rights reserved.

This distribution also includes software licensed under the following terms:

`@react-hook/resize-observer` : [MIT]
> Copyright (c) 2019 Jared Lunde

`@react95/core` : [MIT]
> Copyright (c) 2018 React95

`@yaireo/relative-time` : [MIT]
> Copyright 2019 Yair Even-Or

`allotment` : [MIT]
> Copyright (c) 2021 John Walley  
> Copyright (c) 2021 Gobalsky Labs Ltd.  
> Copyright (c) 2015 - present Microsoft Corporation

`browser-fs-access` : [Apache-2.0]
>  Copyright 2020 Google Inc.

No changes were made.

`classnames` : [MIT]
> Copyright (c) 2018 Jed Watson

`core-js-pure` : [MIT]
> Copyright (c) 2014-2021 Denis Pushkarev

`history` : [MIT]
> Copyright (c) React Training 2016-2020  
> Copyright (c) Remix Software 2020-2021

`kv-storage-polyfill` : [Apache-2.0]
>  Copyright 2019 Google Inc.

No changes were made.

`react` : [MIT]
> Copyright (c) Facebook, Inc. and its affiliates.

`react-dnd` : [MIT]
> Copyright (c) 2015 Dan Abramov

`react-dnd-html5-backend` : [MIT]
> Copyright (c) 2015 Dan Abramov

`react-dom` : [MIT]
> Copyright (c) Facebook, Inc. and its affiliates.

`react-fast-compare` : [MIT]
> Copyright (c) 2018 Formidable Labs  
> Copyright (c) 2017 Evgeny Poberezkin  

`react-hotkeys-hook` : [MIT]
> Copyright (c) 2018 Johannes Klauss

`react-router` : [MIT]
> Copyright (c) React Training

`react-router-dom` : [MIT]
> Copyright (c) React Training

`react-table` : [MIT]
> Copyright (c) 2016 Tanner Linsley

`react-virtual` : [MIT]
> Copyright (c) 2019 Tanner Linsley

`sql.js` : [MIT]
> Copyright (c) 2017 sql.js authors (see AUTHORS)  

`recoil.js`: [MIT]
> Copyright (c) Facebook, Inc. and its affiliates.

AUTHORS
> Ophir LOJKINE <pere.jobs@gmail.com> (https://github.com/lovasoa)  
> @kripken  
> @hankinsoft  
> @firien  
> @dinedal  
> @taytay  
> @kaizhu256  
> @brodybits  

`styled-components` : [MIT]
> Copyright (c) 2016-present Glen Maddern and Maximilian Stoiber

Workbox : [MIT]
> Copyright 2018 Google LLC

Chinook Database : [MIT]
> Copyright (c) 2008-2017 Luis Rocha


[MIT]: https://mit-license.org
[Apache-2.0]: http://www.apache.org/licenses/LICENSE-2.0.html