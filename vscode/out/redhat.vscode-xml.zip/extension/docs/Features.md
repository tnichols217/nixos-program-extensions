# Features

[vscode-xml](https://github.com/redhat-developer/vscode-xml) has a number of notable features available for XML, XSD and DTD support.

- [XML Features](Features/XMLFeatures.md#xml-features)
- [XSD Features](Features/XSDFeatures.md#xsd-features)
- [DTD Features](Features/DTDFeatures.md#dtd-features)
