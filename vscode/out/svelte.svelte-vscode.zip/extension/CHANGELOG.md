# Changelog

See https://github.com/sveltejs/language-tools/releases
