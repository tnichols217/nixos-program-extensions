module.exports = {
    root: false,
    rules: {
        '@typescript-eslint/no-var-requires': 'off'
    }
};
