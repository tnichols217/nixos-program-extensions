<input use:action>
