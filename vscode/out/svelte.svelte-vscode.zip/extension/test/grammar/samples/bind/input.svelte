<script>
    let value;
</script>

<input bind:value>

<Input bind:value />
