<div class:active></div>

<div class:active={!Active}></div>
