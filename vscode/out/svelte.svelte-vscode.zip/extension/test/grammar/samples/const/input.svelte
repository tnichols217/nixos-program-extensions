{#each items as item}
    {@const _item = item}
    {item}
{/each}
