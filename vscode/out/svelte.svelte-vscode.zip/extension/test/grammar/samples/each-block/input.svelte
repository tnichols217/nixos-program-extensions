{#each items as item}
    <div>{item}</div>
{:else}
    <div></div>
{/each}

{#each showGroups as [key, items] (key)}

{/each}
