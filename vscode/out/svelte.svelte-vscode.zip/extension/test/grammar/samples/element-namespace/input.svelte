<svg xmlns:xlink="foo"></svg>
<a xlink:href="foo"></a>
