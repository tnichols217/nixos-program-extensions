<div on:click="{(e) => {console.log(e)}}"></div>

<Component on:click={(e) => {console.log(e)}}></Component>
