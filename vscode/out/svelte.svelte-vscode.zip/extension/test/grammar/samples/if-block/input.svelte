{#if abc}
    <div>{abc}</div>
{:else if 1}
{:else}
{/if}


{#if asd}
  asdddddddddddddddd
  dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
{:else if asd}dddddd{/if}
