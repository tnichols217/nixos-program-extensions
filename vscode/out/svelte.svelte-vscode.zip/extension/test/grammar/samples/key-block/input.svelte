{#key hi}

{/key}
