<input value="1">
<input value={1}>
<input {value}>
<input value="{1}">

<input type=number min=0>

<div tabindex="1" />
<div tabindex={1} />
<div {tabindex} />
<div {tabindex}></div>
<div tabindex="{1}" />

<Input value="1" />
<Input value={1} />
<Input {value} />

<div title="Really?
    {true ? 'Yes' : 'No'}"></div>

<Input hi_hi={false} hi-hi="" />
