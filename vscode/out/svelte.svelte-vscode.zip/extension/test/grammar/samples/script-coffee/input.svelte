<script lang="coffee">
    num = 4
</script>
