<script context="module" lang="ts">
    const a = <string>'b';
</script>
