<script>
    export let abc;
</script>
