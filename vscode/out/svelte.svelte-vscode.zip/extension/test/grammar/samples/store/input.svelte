<script>
import './$types';
import '$lib/foo';
$bar;
</script>

{$bar}
