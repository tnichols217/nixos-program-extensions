<div style:position={position}></div>

<div style:position></div>

<div style:position="relative"></div>
