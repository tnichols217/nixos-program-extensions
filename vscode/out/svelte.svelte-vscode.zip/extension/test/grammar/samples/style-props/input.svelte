<Component --rail-color="black"></Component>
