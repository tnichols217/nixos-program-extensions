<style src="../external.css"></style>
