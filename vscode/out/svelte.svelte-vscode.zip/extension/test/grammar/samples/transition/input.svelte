<div transition:fade></div>

<div in:fade></div>

<div out:fade></div>
